let currentUser = null;
let surveys = [];
let customers = [];
let assignments = [];

// Authentication functions
function login(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorDiv = document.getElementById('error-message');
    
    fetch('login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            currentUser = { role: data.role, userId: data.userId };
            if (data.role === 'ADMIN') {
                window.location.href = 'admin-dashboard.html';
            } else {
                window.location.href = 'customer-survey.html';
            }
        } else {
            errorDiv.textContent = data.message || 'Login failed';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        errorDiv.textContent = 'An error occurred during login';
    });
}

function logout() {
    fetch('login?action=logout')
    .then(() => {
        currentUser = null;
        window.location.href = 'login.html';
    })
    .catch(error => {
        console.error('Error:', error);
        window.location.href = 'login.html';
    });
}

function checkAdminAuth() {
    // This should be implemented to verify admin session
    // For demo purposes, we'll assume authentication is handled by session
}

function checkCustomerAuth() {
    // This should be implemented to verify customer session
    // For demo purposes, we'll assume authentication is handled by session
}

// Admin Dashboard Functions
function showSection(sectionName) {
    // Hide all sections
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => section.classList.remove('active'));
    
    // Show selected section
    document.getElementById(sectionName + '-section').classList.add('active');
    
    // Load section data
    switch(sectionName) {
        case 'surveys':
            loadSurveys();
            break;
        case 'assignments':
            loadAssignments();
            break;
        case 'responses':
            loadPendingResponses();
            break;
    }
}

function loadSurveys() {
    fetch('admin/surveys')
    .then(response => response.json())
    .then(data => {
        surveys = data;
        renderSurveys();
    })
    .catch(error => {
        console.error('Error loading surveys:', error);
        showErrorMessage('Failed to load surveys');
    });
}

function renderSurveys() {
    const tbody = document.getElementById('surveys-tbody');
    if (!tbody) {
        console.error('ERROR: surveys-tbody element not found');
        return;
    }
    
    tbody.innerHTML = '';
    
    if (surveys.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4">No surveys found. Create your first survey!</td></tr>';
        return;
    }
    
    surveys.forEach(survey => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${escapeHtml(survey.title)}</td>
            <td>${escapeHtml(survey.description || 'N/A')}</td>
            <td>${formatDate(survey.createdAt)}</td>
            <td>
                <button onclick="viewSurveyDetails('${survey.id}')">View Details</button>
                <button onclick="editSurvey('${survey.id}')">Edit</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function loadAssignments() {
    fetch('admin/assignments')
    .then(response => response.json())
    .then(data => {
        assignments = data;
        renderAssignments();
    })
    .catch(error => {
        console.error('Error loading assignments:', error);
        showErrorMessage('Failed to load assignments');
    });
}

function renderAssignments() {
    const tbody = document.getElementById('assignments-tbody');
    if (!tbody) {
        console.error('ERROR: assignments-tbody element not found');
        return;
    }
    
    tbody.innerHTML = '';
    
    if (assignments.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6">No assignments found. Assign surveys to customers!</td></tr>';
        return;
    }
    
    assignments.forEach(assignment => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${escapeHtml(assignment.surveyTitle)}</td>
            <td>${escapeHtml(assignment.customerUsername)}</td>
            <td>${escapeHtml(assignment.quarter)}</td>
            <td><span class="status ${assignment.status.toLowerCase().replace('_', '-')}">${assignment.status}</span></td>
            <td>${formatDate(assignment.dueDate)}</td>
            <td>
                <button onclick="viewAssignmentDetails('${assignment.id}')">View</button>
                <button onclick="reassignSurvey('${assignment.id}')">Reassign</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function loadPendingResponses() {
    fetch('admin/pending-responses')
    .then(response => response.json())
    .then(data => {
        renderPendingResponses(data);
    })
    .catch(error => {
        console.error('Error loading pending responses:', error);
        showErrorMessage('Failed to load pending responses');
    });
}

function renderPendingResponses(responses) {
    const container = document.getElementById('pending-responses');
    if (!container) {
        console.error('ERROR: pending-responses element not found');
        return;
    }
    
    container.innerHTML = '';
    
    if (responses.length === 0) {
        container.innerHTML = '<p>No pending responses to review.</p>';
        return;
    }
    
    responses.forEach(response => {
        const card = document.createElement('div');
        card.className = 'response-card';
        card.innerHTML = `
            <div class="response-header">
                <h4>${escapeHtml(response.questionText)}</h4>
                <div class="response-actions">
                    <button class="approve-btn" onclick="approveResponse('${response.id}')">Approve</button>
                    <button class="reject-btn" onclick="rejectResponse('${response.id}')">Reject</button>
                </div>
            </div>
            <p><strong>Response:</strong> ${escapeHtml(response.responseText)}</p>
            <p><small>Submitted: ${formatDate(response.submittedAt)}</small></p>
        `;
        container.appendChild(card);
    });
}

// Modal Functions
function showCreateSurveyModal() {
    document.getElementById('create-survey-modal').style.display = 'block';
    document.getElementById('questions-list').innerHTML = '';
    addQuestion(); // Add first question by default
}

function showAssignSurveyModal() {
    document.getElementById('assign-survey-modal').style.display = 'block';
    loadSurveyOptions();
    loadCustomerOptions();
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        // Remove dynamically created modals
        if (modalId === 'survey-details-modal' || modalId === 'results-modal') {
            modal.remove();
        }
    }
}

function addQuestion() {
    const questionsList = document.getElementById('questions-list');
    const questionIndex = questionsList.children.length;
    
    const questionDiv = document.createElement('div');
    questionDiv.className = 'question-item';
    questionDiv.innerHTML = `
        <div class="form-group">
            <label>Question ${questionIndex + 1}:</label>
            <textarea name="question-text-${questionIndex}" placeholder="Enter question text..." required></textarea>
        </div>
        <div class="form-group">
            <label>Question Type:</label>
            <select name="question-type-${questionIndex}" onchange="handleQuestionTypeChange(${questionIndex})">
                <option value="TEXT">Text Input</option>
                <option value="MULTIPLE_CHOICE">Multiple Choice</option>
                <option value="RATING">Rating (1-5)</option>
                <option value="YES_NO">Yes/No</option>
            </select>
        </div>
        <div class="form-group" id="options-${questionIndex}" style="display: none;">
            <label>Options (comma-separated):</label>
            <textarea name="question-options-${questionIndex}" placeholder="Option 1, Option 2, Option 3..."></textarea>
        </div>
        <div class="form-group">
            <label>
                <input type="checkbox" name="question-required-${questionIndex}">
                Required
            </label>
        </div>
        ${questionIndex > 0 ? `<button type="button" onclick="removeQuestion(this)" class="danger-btn">Remove Question</button>` : ''}
        <hr style="margin: 1rem 0;">
    `;
    
    questionsList.appendChild(questionDiv);
}

function removeQuestion(button) {
    const questionItem = button.closest('.question-item');
    questionItem.remove();
    
    // Renumber remaining questions
    const questionItems = document.querySelectorAll('.question-item');
    questionItems.forEach((item, index) => {
        const label = item.querySelector('label');
        if (label && label.textContent.startsWith('Question')) {
            label.textContent = `Question ${index + 1}:`;
        }
    });
}

function handleQuestionTypeChange(index) {
    const select = document.querySelector(`select[name="question-type-${index}"]`);
    const optionsDiv = document.getElementById(`options-${index}`);
    
    // FIXED: Corrected typo from "select.valucreate-survey-forme" to "select.value"
    if (select.value === 'MULTIPLE_CHOICE') {
        optionsDiv.style.display = 'block';
    } else {
        optionsDiv.style.display = 'none';
    }
}

// Survey Creation
function createSurvey(event) {
    event.preventDefault();
    
    const title = document.getElementById('survey-title').value;
    const description = document.getElementById('survey-description').value;
    
    const questions = [];
    const questionItems = document.querySelectorAll('.question-item');
    
    questionItems.forEach((item, index) => {
        const questionText = item.querySelector(`textarea[name="question-text-${index}"]`)?.value;
        const questionType = item.querySelector(`select[name="question-type-${index}"]`)?.value;
        const isRequired = item.querySelector(`input[name="question-required-${index}"]`)?.checked;
        
        if (!questionText) return; // Skip if question text is empty
        
        let options = null;
        if (questionType === 'MULTIPLE_CHOICE') {
            const optionsTextarea = item.querySelector(`textarea[name="question-options-${index}"]`);
            const optionsText = optionsTextarea ? optionsTextarea.value : '';
            if (optionsText) {
                options = JSON.stringify(optionsText.split(',').map(opt => opt.trim()).filter(opt => opt));
            }
        }
        
        questions.push({
            questionText: questionText,
            questionType: questionType,
            options: options,
            isRequired: isRequired || false
        });
    });
    
    if (questions.length === 0) {
        showErrorMessage('Please add at least one question');
        return;
    }
    
    const formData = new URLSearchParams();
    formData.append('title', title);
    formData.append('description', description);
    formData.append('questions', JSON.stringify(questions));
    
    fetch('admin/create-survey', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: formData.toString()
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeModal('create-survey-modal');
            loadSurveys();
            showSuccessMessage('Survey created successfully!');
        } else {
            showErrorMessage(data.message || 'Failed to create survey');
        }
    })
    .catch(error => {
        console.error('Error creating survey:', error);
        showErrorMessage('An error occurred while creating the survey');
    });
}

// Survey Assignment
function loadSurveyOptions() {
    const select = document.getElementById('assign-survey-select');
    select.innerHTML = '<option value="">Select a survey...</option>';
    
    surveys.forEach(survey => {
        const option = document.createElement('option');
        option.value = survey.id;
        option.textContent = survey.title;
        select.appendChild(option);
    });
}

function loadCustomerOptions() {
    fetch('admin/customers')
    .then(response => response.json())
    .then(data => {
        customers = data;
        const select = document.getElementById('assign-customer-select');
        select.innerHTML = '<option value="">Select a customer...</option>';
        
        customers.forEach(customer => {
            const option = document.createElement('option');
            option.value = customer.id;
            option.textContent = customer.username + ' (' + customer.email + ')';
            select.appendChild(option);
        });
    })
    .catch(error => {
        console.error('Error loading customers:', error);
        showErrorMessage('Failed to load customers');
    });
}

function assignSurvey(event) {
    event.preventDefault();
    
    const surveyId = document.getElementById('assign-survey-select').value;
    const customerId = document.getElementById('assign-customer-select').value;
    const quarter = document.getElementById('assign-quarter').value;
    const dueDate = document.getElementById('assign-due-date').value;
    
    const formData = new URLSearchParams();
    formData.append('surveyId', surveyId);
    formData.append('customerId', customerId);
    formData.append('quarter', quarter);
    formData.append('dueDate', dueDate);
    
    fetch('admin/assign-survey', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: formData.toString()
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeModal('assign-survey-modal');
            loadAssignments();
            showSuccessMessage('Survey assigned successfully!');
        } else {
            showErrorMessage(data.message || 'Failed to assign survey');
        }
    })
    .catch(error => {
        console.error('Error assigning survey:', error);
        showErrorMessage('An error occurred while assigning the survey');
    });
}

// Response Management
function approveResponse(responseId) {
    const formData = new URLSearchParams();
    formData.append('responseId', responseId);
    
    fetch('admin/approve-response', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: formData.toString()
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            loadPendingResponses();
            showSuccessMessage('Response approved successfully!');
        } else {
            showErrorMessage('Failed to approve response');
        }
    })
    .catch(error => {
        console.error('Error approving response:', error);
        showErrorMessage('An error occurred while approving the response');
    });
}

function rejectResponse(responseId) {
    if (confirm('Are you sure you want to reject this response? This action cannot be undone.')) {
        const formData = new URLSearchParams();
        formData.append('responseId', responseId);
        
        fetch('admin/reject-response', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: formData.toString()
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadPendingResponses();
                showSuccessMessage('Response rejected successfully!');
            } else {
                showErrorMessage('Failed to reject response');
            }
        })
        .catch(error => {
            console.error('Error rejecting response:', error);
            showErrorMessage('An error occurred while rejecting the response');
        });
    }
}

// Additional Admin Functions
function viewSurveyDetails(surveyId) {
    fetch(`admin/survey-details?surveyId=${surveyId}`)
    .then(response => response.json())
    .then(data => {
        if (data) {
            displaySurveyDetailsModal(data);
        }
    })
    .catch(error => {
        console.error('Error loading survey details:', error);
        showErrorMessage('Failed to load survey details');
    });
}

function displaySurveyDetailsModal(survey) {
    // Create and show modal with survey details
    const modalHTML = `
        <div id="survey-details-modal" class="modal" style="display: block;">
            <div class="modal-content">
                <span class="close" onclick="closeModal('survey-details-modal')">&times;</span>
                <h3>${escapeHtml(survey.title)}</h3>
                <p>${escapeHtml(survey.description || 'No description provided')}</p>
                <h4>Questions:</h4>
                ${survey.questions && survey.questions.length > 0 ? survey.questions.map((q, index) => `
                    <div class="question-preview">
                        <strong>Q${index + 1}: ${escapeHtml(q.questionText)}</strong>
                        <br>Type: ${q.questionType}
                        ${q.isRequired ? ' (Required)' : ''}
                        ${q.options ? `<br>Options: ${JSON.parse(q.options).map(escapeHtml).join(', ')}` : ''}
                    </div>
                `).join('') : '<p>No questions added yet.</p>'}
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
}

function editSurvey(surveyId) {
    // Implementation for editing surveys
    showErrorMessage('Survey editing feature coming soon!');
}

function viewAssignmentDetails(assignmentId) {
    // Implementation for viewing assignment details
    showErrorMessage('Assignment details feature coming soon!');
}

function reassignSurvey(assignmentId) {
    // Implementation for reassigning surveys
    const newCustomerId = prompt('Enter new customer ID:');
    if (newCustomerId) {
        const formData = new URLSearchParams();
        formData.append('assignmentId', assignmentId);
        formData.append('newCustomerId', newCustomerId);
        
        fetch('admin/reassign-survey', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: formData.toString()
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadAssignments();
                showSuccessMessage('Survey reassigned successfully!');
            } else {
                showErrorMessage('Failed to reassign survey');
            }
        })
        .catch(error => {
            console.error('Error reassigning survey:', error);
            showErrorMessage('An error occurred while reassigning the survey');
        });
    }
}

// Utility Functions
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    
    try {
        const date = new Date(dateString);
        return date.toLocaleDateString();
    } catch (error) {
        return dateString;
    }
}

function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.toString().replace(/[&<>"']/g, m => map[m]);
}

function showSuccessMessage(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'success-message';
    messageDiv.textContent = message;
    
    document.body.insertBefore(messageDiv, document.body.firstChild);
    
    setTimeout(() => {
        messageDiv.remove();
    }, 5000);
}

function showErrorMessage(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'error-message';
    messageDiv.textContent = message;
    
    document.body.insertBefore(messageDiv, document.body.firstChild);
    
    setTimeout(() => {
        messageDiv.remove();
    }, 5000);
}

// Generate current quarter helper
function getCurrentQuarter() {
    const now = new Date();
    const year = now.getFullYear();
    const quarter = Math.floor((now.getMonth() + 3) / 3);
    return `${year}-Q${quarter}`;
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', login);
    }
    
    // Create survey form
    const createSurveyForm = document.getElementById('create-survey-form');
    if (createSurveyForm) {
        createSurveyForm.addEventListener('submit', createSurvey);
    }
    
    // Assign survey form
    const assignSurveyForm = document.getElementById('assign-survey-form');
    if (assignSurveyForm) {
        assignSurveyForm.addEventListener('submit', assignSurvey);
    }
    
    // Auto-fill quarter field
    const quarterField = document.getElementById('assign-quarter');
    if (quarterField) {
        quarterField.value = getCurrentQuarter();
    }
    
    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (event.target === modal) {
                closeModal(modal.id);
            }
        });
    });
});