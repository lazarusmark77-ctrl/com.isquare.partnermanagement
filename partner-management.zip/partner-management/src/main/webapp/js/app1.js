let currentUser = null;
let surveys = [];
let customers = [];
let assignments = [];

// Authentication functions
function login(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorDiv = document.getElementById('error-message');
    
    fetch('login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            currentUser = { role: data.role, userId: data.userId };
            if (data.role === 'ADMIN') {
                window.location.href = 'admin-dashboard.html';
            } else {
                window.location.href = 'customer-dashboard.html';
            }
        } else {
            errorDiv.textContent = data.message || 'Login failed';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        errorDiv.textContent = 'An error occurred during login';
    });
}

function logout() {
    fetch('login?action=logout')
    .then(() => {
        currentUser = null;
        window.location.href = 'login.html';
    })
    .catch(error => {
        console.error('Error:', error);
        window.location.href = 'login.html';
    });
}

function checkAdminAuth() {
    // This should be implemented to verify admin session
    // For demo purposes, we'll assume authentication is handled by session
}

function checkCustomerAuth() {
    // This should be implemented to verify customer session
    // For demo purposes, we'll assume authentication is handled by session
}

// Admin Dashboard Functions
function showSection(sectionName) {
    // Hide all sections
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => section.classList.remove('active'));
    
    // Show selected section
    document.getElementById(sectionName + '-section').classList.add('active');
    
    // Load section data
    switch(sectionName) {
        case 'surveys':
            loadSurveys();
            break;
        case 'assignments':
            loadAssignments();
            break;
        case 'responses':
            loadPendingResponses();
            break;
    }
}

function loadSurveys() {
    fetch('admin/surveys')
    .then(response => response.json())
    .then(data => {
        surveys = data;
        renderSurveys();
    })
    .catch(error => {
        console.error('Error loading surveys:', error);
    });
}

function renderSurveys() {
    const tbody = document.getElementById('surveys-tbody');
    tbody.innerHTML = '';
    
    surveys.forEach(survey => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${survey.title}</td>
            <td>${survey.description || 'N/A'}</td>
            <td>${formatDate(survey.createdAt)}</td>
            <td>
                <button onclick="viewSurveyDetails(${survey.id})">View Details</button>
                <button onclick="editSurvey(${survey.id})">Edit</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function loadAssignments() {
    fetch('admin/assignments')
    .then(response => response.json())
    .then(data => {
        assignments = data;
        renderAssignments();
    })
    .catch(error => {
        console.error('Error loading assignments:', error);
    });
}

function renderAssignments() {
    const tbody = document.getElementById('assignments-tbody');
    tbody.innerHTML = '';
    
    assignments.forEach(assignment => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${assignment.surveyTitle}</td>
            <td>${assignment.customerUsername}</td>
            <td>${assignment.quarter}</td>
            <td><span class="status ${assignment.status.toLowerCase().replace('_', '-')}">${assignment.status}</span></td>
            <td>${formatDate(assignment.dueDate)}</td>
            <td>
                <button onclick="viewAssignmentDetails(${assignment.id})">View</button>
                <button onclick="reassignSurvey(${assignment.id})">Reassign</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function loadPendingResponses() {
    fetch('admin/pending-responses')
    .then(response => response.json())
    .then(data => {
        renderPendingResponses(data);
    })
    .catch(error => {
        console.error('Error loading pending responses:', error);
    });
}

function renderPendingResponses(responses) {
    const container = document.getElementById('pending-responses');
    container.innerHTML = '';
    
    if (responses.length === 0) {
        container.innerHTML = '<p>No pending responses to review.</p>';
        return;
    }
    
    responses.forEach(response => {
        const card = document.createElement('div');
        card.className = 'response-card';
        card.innerHTML = `
            <div class="response-header">
                <h4>${response.questionText}</h4>
                <div class="response-actions">
                    <button class="approve-btn" onclick="approveResponse(${response.id})">Approve</button>
                    <button class="reject-btn" onclick="rejectResponse(${response.id})">Reject</button>
                </div>
            </div>
            <p><strong>Response:</strong> ${response.responseText}</p>
            <p><small>Submitted: ${formatDate(response.submittedAt)}</small></p>
        `;
        container.appendChild(card);
    });
}

// Modal Functions
function showCreateSurveyModal() {
    document.getElementById('create-survey-modal').style.display = 'block';
    document.getElementById('questions-list').innerHTML = '';
    addQuestion(); // Add first question by default
}

function showAssignSurveyModal() {
    document.getElementById('assign-survey-modal').style.display = 'block';
    loadSurveyOptions();
    loadCustomerOptions();
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function addQuestion() {
    const questionsList = document.getElementById('questions-list');
    const questionIndex = questionsList.children.length;
    
    const questionDiv = document.createElement('div');
    questionDiv.className = 'question-item';
    questionDiv.innerHTML = `
        <div class="form-group">
            <label>Question ${questionIndex + 1}:</label>
            <textarea name="question-text-${questionIndex}" placeholder="Enter question text..." required></textarea>
        </div>
        <div class="form-group">
            <label>Question Type:</label>
            <select name="question-type-${questionIndex}" onchange="handleQuestionTypeChange(${questionIndex})">
                <option value="TEXT">Text Input</option>
                <option value="MULTIPLE_CHOICE">Multiple Choice</option>
                <option value="RATING">Rating (1-5)</option>
                <option value="YES_NO">Yes/No</option>
            </select>
        </div>
        <div class="form-group" id="options-${questionIndex}" style="display: none;">
            <label>Options (comma-separated):</label>
            <textarea name="question-options-${questionIndex}" placeholder="Option 1, Option 2, Option 3..."></textarea>
        </div>
        <div class="form-group">
            <label>
                <input type="checkbox" name="question-required-${questionIndex}">
                Required
            </label>
        </div>
        <hr style="margin: 1rem 0;">
    `;
    
    questionsList.appendChild(questionDiv);
}

function handleQuestionTypeChange(index) {
    const select = document.querySelector(`select[name="question-type-${index}"]`);
    const optionsDiv = document.getElementById(`options-${index}`);
    
    if (select.valucreate-survey-forme === 'MULTIPLE_CHOICE') {
        optionsDiv.style.display = 'block';
    } else {
        optionsDiv.style.display = 'none';
    }
}

// Survey Creation
function createSurvey(event) {
alert ('test');
    event.preventDefault();

    const title = document.getElementById('survey-title').value;
	
    const description = document.getElementById('survey-description').value;
    
    const questions = [];
    const questionItems = document.querySelectorAll('.question-item');
    
    questionItems.forEach((item, index) => {
        const questionText = item.querySelector(`textarea[name="question-text-${index}"]`).value;
        const questionType = item.querySelector(`select[name="question-type-${index}"]`).value;
        const isRequired = item.querySelector(`input[name="question-required-${index}"]`).checked;
        
        let options = null;
        if (questionType === 'MULTIPLE_CHOICE') {
            const optionsText = item.querySelector(`textarea[name="question-options-${index}"]`).value;
            if (optionsText) {
                options = JSON.stringify(optionsText.split(',').map(opt => opt.trim()));
            }
        }
        
        questions.push({
            questionText: questionText,
            questionType: questionType,
            options: options,
            isRequired: isRequired
        });
    });
    
    const formData = new FormData();
    formData.append('title', title);
    formData.append('description', description);
    formData.append('questions', JSON.stringify(questions));
    
    fetch('admin/create-survey', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeModal('create-survey-modal');
            loadSurveys();
            showSuccessMessage('Survey created successfully!');
        } else {
            showErrorMessage(data.message || 'Failed to create survey');
        }
    })
    .catch(error => {
        console.error('Error creating survey:', error);
        showErrorMessage('An error occurred while creating the survey');
    });
}

// Survey Assignment
function loadSurveyOptions() {
    const select = document.getElementById('assign-survey-select');
    select.innerHTML = '<option value="">Select a survey...</option>';
    
    surveys.forEach(survey => {
        const option = document.createElement('option');
        option.value = survey.id;
        option.textContent = survey.title;
        select.appendChild(option);
    });
}

function loadCustomerOptions() {
    fetch('admin/customers')
    .then(response => response.json())
    .then(data => {
        customers = data;
        const select = document.getElementById('assign-customer-select');
        select.innerHTML = '<option value="">Select a customer...</option>';
        
        customers.forEach(customer => {
            const option = document.createElement('option');
            option.value = customer.id;
            option.textContent = customer.username + ' (' + customer.email + ')';
            select.appendChild(option);
        });
    })
    .catch(error => {
        console.error('Error loading customers:', error);
    });
}

function assignSurvey(event) {
    event.preventDefault();
    
    const surveyId = document.getElementById('assign-survey-select').value;
    const customerId = document.getElementById('assign-customer-select').value;
    const quarter = document.getElementById('assign-quarter').value;
    const dueDate = document.getElementById('assign-due-date').value;
    
    const formData = new FormData();
    formData.append('surveyId', surveyId);
    formData.append('customerId', customerId);
    formData.append('quarter', quarter);
    formData.append('dueDate', dueDate);
    
    fetch('admin/assign-survey', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeModal('assign-survey-modal');
            loadAssignments();
            showSuccessMessage('Survey assigned successfully!');
        } else {
            showErrorMessage(data.message || 'Failed to assign survey');
        }
    })
    .catch(error => {
        console.error('Error assigning survey:', error);
        showErrorMessage('An error occurred while assigning the survey');
    });
}

// Response Management
function approveResponse(responseId) {
    const formData = new FormData();
    formData.append('responseId', responseId);
    
    fetch('admin/approve-response', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            loadPendingResponses();
            showSuccessMessage('Response approved successfully!');
        } else {
            showErrorMessage('Failed to approve response');
        }
    })
    .catch(error => {
        console.error('Error approving response:', error);
        showErrorMessage('An error occurred while approving the response');
    });
}

function rejectResponse(responseId) {
    if (confirm('Are you sure you want to reject this response? This action cannot be undone.')) {
        const formData = new FormData();
        formData.append('responseId', responseId);
        
        fetch('admin/reject-response', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadPendingResponses();
                showSuccessMessage('Response rejected successfully!');
            } else {
                showErrorMessage('Failed to reject response');
            }
        })
        .catch(error => {
            console.error('Error rejecting response:', error);
            showErrorMessage('An error occurred while rejecting the response');
        });
    }
}

// Customer Dashboard Functions
function loadAssignedSurveys() {
    fetch('survey/my-assignments')
    .then(response => response.json())
    .then(data => {
        renderAssignedSurveys(data);
    })
    .catch(error => {
        console.error('Error loading assigned surveys:', error);
    });
}

function renderAssignedSurveys(assignments) {
    const container = document.getElementById('assigned-surveys');
    container.innerHTML = '';
    
    if (assignments.length === 0) {
        container.innerHTML = '<p>No surveys assigned to you at this time.</p>';
        return;
    }
    
    assignments.forEach(assignment => {
        const card = document.createElement('div');
        card.className = 'survey-card';
        card.innerHTML = `
            <h3>${assignment.surveyTitle}</h3>
            <span class="status ${assignment.status.toLowerCase().replace('_', '-')}">${assignment.status}</span>
            <p><strong>Quarter:</strong> ${assignment.quarter}</p>
            <p><strong>Due Date:</strong> ${formatDate(assignment.dueDate)}</p>
            <div class="card-actions">
                ${assignment.status === 'ASSIGNED' ? 
                    `<button onclick="startSurvey(${assignment.id})">Start Survey</button>` : 
                    assignment.status === 'IN_PROGRESS' ? 
                        `<button onclick="continueSurvey(${assignment.id})">Continue Survey</button>` :
                        `<button onclick="viewSurveyResults(${assignment.id})">View Results</button>`
                }
            </div>
        `;
        container.appendChild(card);
    });
}

function startSurvey(assignmentId) {
    // Mark survey as in progress
    const formData = new FormData();
    formData.append('assignmentId', assignmentId);
    
    fetch('survey/start', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.location.href = `survey-form.html?assignmentId=${assignmentId}`;
        } else {
            showErrorMessage('Failed to start survey');
        }
    })
    .catch(error => {
        console.error('Error starting survey:', error);
        showErrorMessage('An error occurred while starting the survey');
    });
}

function continueSurvey(assignmentId) {
    window.location.href = `survey-form.html?assignmentId=${assignmentId}`;
}

// Survey Form Functions
function loadSurveyForm() {
    const urlParams = new URLSearchParams(window.location.search);
    const assignmentId = urlParams.get('assignmentId');
    
    if (!assignmentId) {
        window.location.href = 'customer-dashboard.html';
        return;
    }
    
    fetch(`survey/details?assignmentId=${assignmentId}`)
    .then(response => response.json())
    .then(data => {
        if (data) {
            renderSurveyForm(data, assignmentId);
        } else {
            showErrorMessage('Survey not found');
        }
    })
    .catch(error => {
        console.error('Error loading survey:', error);
        showErrorMessage('Failed to load survey');
    });
}

function renderSurveyForm(survey, assignmentId) {
    document.getElementById('survey-title').textContent = survey.title;
    document.getElementById('survey-description').textContent = survey.description || '';
    
    const questionsContainer = document.getElementById('questions-container');
    questionsContainer.innerHTML = '';
    
    survey.questions.forEach((question, index) => {
        const questionDiv = document.createElement('div');
        questionDiv.className = 'question';
        
        let questionHTML = `
            <div class="question-header">
                <span class="question-number">Question ${index + 1}</span>
                ${question.isRequired ? '<span class="required">*Required</span>' : ''}
            </div>
            <div class="question-text">${question.questionText}</div>
        `;
        
        // Add input based on question type
        switch (question.questionType) {
            case 'TEXT':
                questionHTML += `<textarea name="response-${question.id}" rows="3" placeholder="Enter your response..."></textarea>`;
                break;
                
            case 'MULTIPLE_CHOICE':
                if (question.options) {
                    const options = JSON.parse(question.options);
                    questionHTML += '<div class="question-options">';
                    options.forEach((option, optIndex) => {
                        questionHTML += `
                            <label>
                                <input type="radio" name="response-${question.id}" value="${option}">
                                ${option}
                            </label>
                        `;
                    });
                    questionHTML += '</div>';
                }
                break;
                
            case 'RATING':
                questionHTML += `
                    <div class="rating-container">
                        <span>1</span>
                        ${[1,2,3,4,5].map(rating => `
                            <label>
                                <input type="radio" name="response-${question.id}" value="${rating}">
                                ${rating}
                            </label>
                        `).join('')}
                        <span>5</span>
                    </div>
                `;
                break;
                
            case 'YES_NO':
                questionHTML += `
                    <div class="question-options">
                        <label>
                            <input type="radio" name="response-${question.id}" value="Yes">
                            Yes
                        </label>
                        <label>
                            <input type="radio" name="response-${question.id}" value="No">
                            No
                        </label>
                    </div>
                `;
                break;
        }
        
        questionDiv.innerHTML = questionHTML;
        questionsContainer.appendChild(questionDiv);
    });
    
    // Store assignment ID for form submission
    document.getElementById('survey-form').dataset.assignmentId = assignmentId;
}

function submitSurvey(event) {
    event.preventDefault();
    
    const assignmentId = event.target.dataset.assignmentId;
    const formData = new FormData(event.target);
    
    // Collect all responses
    const responses = [];
    const questions = document.querySelectorAll('.question');
    
    questions.forEach((questionDiv, index) => {
        const questionId = questionDiv.querySelector('[name^="response-"]').name.split('-')[1];
        const responseElement = questionDiv.querySelector(`[name="response-${questionId}"]`);
        
        let responseValue = '';
        
        if (responseElement.type === 'radio') {
            const checkedRadio = questionDiv.querySelector(`input[name="response-${questionId}"]:checked`);
            if (checkedRadio) {
                responseValue = checkedRadio.value;
            }
        } else {
            responseValue = responseElement.value;
        }
        
        if (responseValue) {
            responses.push({
                questionId: parseInt(questionId),
                responseText: responseValue
            });
        }
    });
    
    const submitFormData = new FormData();
    submitFormData.append('assignmentId', assignmentId);
    submitFormData.append('responses', JSON.stringify(responses));
    
    fetch('survey/submit', {
        method: 'POST',
        body: submitFormData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccessMessage('Survey submitted successfully!');
            setTimeout(() => {
                window.location.href = 'customer-dashboard.html';
            }, 2000);
        } else {
            showErrorMessage(data.message || 'Failed to submit survey');
        }
    })
    .catch(error => {
        console.error('Error submitting survey:', error);
        showErrorMessage('An error occurred while submitting the survey');
    });
}

function saveDraft() {
    // Implementation for saving draft responses
    showSuccessMessage('Draft saved successfully!');
}

function goBack() {
    window.location.href = 'customer-dashboard.html';
}

// Utility Functions
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    
    try {
        const date = new Date(dateString);
        return date.toLocaleDateString();
    } catch (error) {
        return dateString;
    }
}

function showSuccessMessage(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'success-message';
    messageDiv.textContent = message;
    
    document.body.insertBefore(messageDiv, document.body.firstChild);
    
    setTimeout(() => {
        messageDiv.remove();
    }, 5000);
}

function showErrorMessage(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'error-message';
    messageDiv.textContent = message;
    
    document.body.insertBefore(messageDiv, document.body.firstChild);
    
    setTimeout(() => {
        messageDiv.remove();
    }, 5000);
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', login);
    }
    
    // Create survey form
    const createSurveyForm = document.getElementById('create-survey-form');
    if (createSurveyForm) {
        createSurveyForm.addEventListener('submit', createSurvey);
    }
    
    // Assign survey form
    const assignSurveyForm = document.getElementById('assign-survey-form');
    if (assignSurveyForm) {
        assignSurveyForm.addEventListener('submit', assignSurvey);
    }
    
    // Survey form
    const surveyForm = document.getElementById('survey-form');
    if (surveyForm) {
        surveyForm.addEventListener('submit', submitSurvey);
    }
    
    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
});

// Additional Admin Functions
function viewSurveyDetails(surveyId) {
    fetch(`admin/survey-details?surveyId=${surveyId}`)
    .then(response => response.json())
    .then(data => {
        if (data) {
            displaySurveyDetailsModal(data);
        }
    })
    .catch(error => {
        console.error('Error loading survey details:', error);
    });
}

function displaySurveyDetailsModal(survey) {
    // Create and show modal with survey details
    const modalHTML = `
        <div id="survey-details-modal" class="modal" style="display: block;">
            <div class="modal-content">
                <span class="close" onclick="closeModal('survey-details-modal')">&times;</span>
                <h3>${survey.title}</h3>
                <p>${survey.description || 'No description provided'}</p>
                <h4>Questions:</h4>
                ${survey.questions.map((q, index) => `
                    <div class="question-preview">
                        <strong>Q${index + 1}: ${q.questionText}</strong>
                        <br>Type: ${q.questionType}
                        ${q.isRequired ? ' (Required)' : ''}
                        ${q.options ? `<br>Options: ${JSON.parse(q.options).join(', ')}` : ''}
                    </div>
                `).join('')}
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
}

function editSurvey(surveyId) {
    // Implementation for editing surveys
    showErrorMessage('Survey editing feature coming soon!');
}

function viewAssignmentDetails(assignmentId) {
    // Implementation for viewing assignment details
    showErrorMessage('Assignment details feature coming soon!');
}

function reassignSurvey(assignmentId) {
    // Implementation for reassigning surveys
    const newCustomerId = prompt('Enter new customer ID:');
    if (newCustomerId) {
        const formData = new FormData();
        formData.append('assignmentId', assignmentId);
        formData.append('newCustomerId', newCustomerId);
        
        fetch('admin/reassign-survey', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadAssignments();
                showSuccessMessage('Survey reassigned successfully!');
            } else {
                showErrorMessage('Failed to reassign survey');
            }
        })
        .catch(error => {
            console.error('Error reassigning survey:', error);
            showErrorMessage('An error occurred while reassigning the survey');
        });
    }
}

function viewSurveyResults(assignmentId) {
    fetch(`survey/responses?assignmentId=${assignmentId}`)
    .then(response => response.json())
    .then(data => {
        displayResultsModal(data);
    })
    .catch(error => {
        console.error('Error loading survey results:', error);
    });
}

function displayResultsModal(responses) {
    const modalHTML = `
        <div id="results-modal" class="modal" style="display: block;">
            <div class="modal-content">
                <span class="close" onclick="closeModal('results-modal')">&times;</span>
                <h3>Your Survey Responses</h3>
                ${responses.map(response => `
                    <div class="response-item">
                        <strong>${response.questionText}</strong>
                        <p>${response.responseText}</p>
                        <small>Status: ${response.isApproved ? 'Approved' : 'Pending Approval'}</small>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
}

// Generate current quarter helper
function getCurrentQuarter() {
    const now = new Date();
    const year = now.getFullYear();
    const quarter = Math.floor((now.getMonth() + 3) / 3);
    return `${year}-Q${quarter}`;
}

// Auto-fill quarter field
document.addEventListener('DOMContentLoaded', function() {
    const quarterField = document.getElementById('assign-quarter');
    if (quarterField) {
        quarterField.value = getCurrentQuarter();
    }
});