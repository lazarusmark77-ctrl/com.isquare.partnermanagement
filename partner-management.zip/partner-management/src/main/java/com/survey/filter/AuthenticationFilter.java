package com.survey.filter;

import com.survey.model.User;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter({"/admin/*", "/survey/*"})
public class AuthenticationFilter implements Filter {
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialize if needed
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        String requestURI = httpRequest.getRequestURI();
        
        // Skip authentication for login page and static resources
        if (requestURI.endsWith("/login") || 
            requestURI.contains("/css/") || 
            requestURI.contains("/js/") || 
            requestURI.contains("/images/")) {
            chain.doFilter(request, response);
            return;
        }
        
        HttpSession session = httpRequest.getSession(false);
        User user = null;
        
        if (session != null) {
            user = (User) session.getAttribute("user");
        }
        
        if (user == null) {
            if (isAjaxRequest(httpRequest)) {
                httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                httpResponse.setContentType("application/json");
                httpResponse.getWriter().write("{\"error\": \"Authentication required\", \"redirect\": \"login.html\"}");
            } else {
                httpResponse.sendRedirect(httpRequest.getContextPath() + "/login.html");
            }
            return;
        }
        
        // Check role-based access
        if (requestURI.contains("/admin/") && !"ADMIN".equals(user.getRole())) {
            httpResponse.setStatus(HttpServletResponse.SC_FORBIDDEN);
            if (isAjaxRequest(httpRequest)) {
                httpResponse.setContentType("application/json");
                httpResponse.getWriter().write("{\"error\": \"Access denied. Admin role required.\"}");
            } else {
                httpResponse.sendRedirect(httpRequest.getContextPath() + "/access-denied.html");
            }
            return;
        }
        
        chain.doFilter(request, response);
    }
    
    private boolean isAjaxRequest(HttpServletRequest request) {
        String requestedWith = request.getHeader("X-Requested-With");
        return "XMLHttpRequest".equals(requestedWith) || 
               "application/json".equals(request.getContentType()) ||
               request.getRequestURI().contains("/admin/") ||
               request.getRequestURI().contains("/survey/");
    }
    
    @Override
    public void destroy() {
        // Cleanup if needed
    }
}
