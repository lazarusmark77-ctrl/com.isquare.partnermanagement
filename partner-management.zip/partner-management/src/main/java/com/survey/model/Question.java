package com.survey.model;

public class Question {
    private String id;
    private String surveyId;
    private String questionText;
    private String questionType;
    private String options; // JSON string for multiple choice options
    private boolean isRequired;
    private int questionOrder;
    
    // Constructors
    public Question() {}
    
    public Question(String surveyId, String questionText, String questionType, boolean isRequired, int questionOrder) {
        this.surveyId = surveyId;
        this.questionText = questionText;
        this.questionType = questionType;
        this.isRequired = isRequired;
        this.questionOrder = questionOrder;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getSurveyId() { return surveyId; }
    public void setSurveyId(String surveyId) { this.surveyId = surveyId; }
    
    public String getQuestionText() { return questionText; }
    public void setQuestionText(String questionText) { this.questionText = questionText; }
    
    public String getQuestionType() { return questionType; }
    public void setQuestionType(String questionType) { this.questionType = questionType; }
    
    public String getOptions() { return options; }
    public void setOptions(String options) { this.options = options; }
    
    public boolean isRequired() { return isRequired; }
    public void setRequired(boolean required) { isRequired = required; }
    
    public int getQuestionOrder() { return questionOrder; }
    public void setQuestionOrder(int questionOrder) { this.questionOrder = questionOrder; }
}