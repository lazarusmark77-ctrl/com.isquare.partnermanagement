package com.survey.model;

public class SurveyAssignment {
    private String id;
    private String surveyId;
    private String customerId;
    private String assignedBy;
    private String assignedAt;
    private String status;
    private String quarter;
    private String dueDate;
    private String surveyTitle;
    private String customerUsername;
    
    // Constructors
    public SurveyAssignment() {}
    
    public SurveyAssignment(String surveyId, String customerId, String assignedBy, String quarter, String dueDate) {
        this.surveyId = surveyId;
        this.customerId = customerId;
        this.assignedBy = assignedBy;
        this.quarter = quarter;
        this.dueDate = dueDate;
        this.status = "ASSIGNED";
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getSurveyId() { return surveyId; }
    public void setSurveyId(String surveyId) { this.surveyId = surveyId; }
    
    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }
    
    public String getAssignedBy() { return assignedBy; }
    public void setAssignedBy(String assignedBy) { this.assignedBy = assignedBy; }
    
    public String getAssignedAt() { return assignedAt; }
    public void setAssignedAt(String assignedAt) { this.assignedAt = assignedAt; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public String getQuarter() { return quarter; }
    public void setQuarter(String quarter) { this.quarter = quarter; }
    
    public String getDueDate() { return dueDate; }
    public void setDueDate(String dueDate) { this.dueDate = dueDate; }
    
    public String getSurveyTitle() { return surveyTitle; }
    public void setSurveyTitle(String surveyTitle) { this.surveyTitle = surveyTitle; }
    
    public String getCustomerUsername() { return customerUsername; }
    public void setCustomerUsername(String customerUsername) { this.customerUsername = customerUsername; }
}
