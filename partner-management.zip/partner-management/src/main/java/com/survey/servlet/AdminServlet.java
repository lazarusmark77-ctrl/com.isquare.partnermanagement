package com.survey.servlet;

import com.survey.dao.SurveyDAO;
import com.survey.dao.UserDAO;
import com.survey.dao.ResponseDAO;
import com.survey.model.*;
import com.google.gson.Gson;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class AdminServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private SurveyDAO surveyDAO = new SurveyDAO();
    private UserDAO userDAO = new UserDAO();
    private ResponseDAO responseDAO = new ResponseDAO();
    private Gson gson = new Gson();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        if (!isAdminAuthenticated(request, response)) {
            return;
        }
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            pathInfo = "/";
        }
        
        System.out.println("DEBUG: AdminServlet GET request - Path: " + pathInfo);
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            switch (pathInfo) {
                case "/surveys":
                    List<Survey> surveys = surveyDAO.getAllSurveys();
                    out.print(gson.toJson(surveys));
                    break;
                    
                case "/customers":
                    List<User> customers = userDAO.getCustomers();
                    out.print(gson.toJson(customers));
                    break;
                    
                case "/assignments":
                    List<SurveyAssignment> assignments = surveyDAO.getAllAssignments();
                    out.print(gson.toJson(assignments));
                    break;
                    
                case "/pending-responses":
                    List<Response> pendingResponses = responseDAO.getPendingResponses();
                    out.print(gson.toJson(pendingResponses));
                    break;
                    
                case "/survey-details":
                    String surveyId = request.getParameter("surveyId");
                    if (surveyId != null && !surveyId.trim().isEmpty()) {
                        Survey surveyWithQuestions = surveyDAO.getSurveyWithQuestions(surveyId);
                        out.print(gson.toJson(surveyWithQuestions));
                    } else {
                        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                        out.print("{\"error\": \"surveyId parameter is required\"}");
                    }
                    break;
                    
                default:
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    out.print("{\"error\": \"Endpoint not found\"}");
            }
        } catch (Exception e) {
            System.err.println("ERROR: Exception in AdminServlet GET: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"" + e.getMessage() + "\"}");
            e.printStackTrace();
        } finally {
            out.flush();
            out.close();
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        if (!isAdminAuthenticated(request, response)) {
            return;
        }
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            pathInfo = "/";
        }
        
        System.out.println("DEBUG: AdminServlet POST request - Path: " + pathInfo);
        System.out.println("DEBUG: User ID: " + user.getId());
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            switch (pathInfo) {
                case "/create-survey":
                    createSurvey(request, response, user.getId());
                    return;
                    
                case "/assign-survey":
                    assignSurvey(request, response, user.getId());
                    return;
                    
                case "/approve-response":
                    String responseId = request.getParameter("responseId");
                    if (responseId != null && !responseId.trim().isEmpty()) {
                        boolean approved = responseDAO.approveResponse(responseId, user.getId());
                        out.print("{\"success\": " + approved + "}");
                    } else {
                        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                        out.print("{\"error\": \"responseId parameter is required\"}");
                    }
                    break;
                    
                case "/reject-response":
                    String rejectResponseId = request.getParameter("responseId");
                    if (rejectResponseId != null && !rejectResponseId.trim().isEmpty()) {
                        boolean rejected = responseDAO.rejectResponse(rejectResponseId);
                        out.print("{\"success\": " + rejected + "}");
                    } else {
                        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                        out.print("{\"error\": \"responseId parameter is required\"}");
                    }
                    break;
                    
                case "/reassign-survey":
                    String assignmentId = request.getParameter("assignmentId");
                    String newCustomerId = request.getParameter("newCustomerId");
                    if (assignmentId != null && !assignmentId.trim().isEmpty() && 
                        newCustomerId != null && !newCustomerId.trim().isEmpty()) {
                        boolean reassigned = surveyDAO.reassignSurvey(assignmentId, newCustomerId);
                        out.print("{\"success\": " + reassigned + "}");
                    } else {
                        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                        out.print("{\"error\": \"assignmentId and newCustomerId parameters are required\"}");
                    }
                    break;
                    
                default:
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    out.print("{\"error\": \"Endpoint not found\"}");
            }
        } catch (Exception e) {
            System.err.println("ERROR: Exception in AdminServlet POST: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"" + e.getMessage() + "\"}");
            e.printStackTrace();
        } finally {
            out.flush();
            out.close();
        }
    }
    
    private boolean isAdminAuthenticated(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        HttpSession session = request.getSession(false);
        User user = null;
        
        if (session != null) {
            user = (User) session.getAttribute("user");
        }
        
        if (user == null || !"ADMIN".equals(user.getRole())) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            PrintWriter out = response.getWriter();
            out.print("{\"error\": \"Authentication required\", \"redirect\": \"login.html\"}");
            out.flush();
            out.close();
            return false;
        }
        
        return true;
    }
    
    private void createSurvey(HttpServletRequest request, HttpServletResponse response, String userId) 
            throws IOException {
        
        System.out.println("DEBUG: createSurvey method called for user ID: " + userId);
        
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String questionsJson = request.getParameter("questions");
        
        System.out.println("DEBUG: Survey parameters - Title: '" + title + "', Description: '" + description + "', Questions JSON: '" + questionsJson + "'");
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        // Validate input
        if (title == null || title.trim().isEmpty()) {
            System.err.println("ERROR: Survey title is empty or null");
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"success\": false, \"message\": \"Survey title is required\"}");
            out.flush();
            out.close();
            return;
        }
        
        // Test database connection first
        if (!surveyDAO.testDatabaseConnection()) {
            System.err.println("ERROR: Database connection test failed");
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"success\": false, \"message\": \"Database connection failed\"}");
            out.flush();
            out.close();
            return;
        }
        
        Survey survey = new Survey(title.trim(), description != null ? description.trim() : "", userId);
        System.out.println("DEBUG: Created survey object: " + survey.getTitle());
        
        if (surveyDAO.createSurvey(survey)) {
            System.out.println("DEBUG: Survey created successfully with ID: " + survey.getId());
            
            if (questionsJson != null && !questionsJson.trim().isEmpty()) {
                try {
                    System.out.println("DEBUG: Processing questions JSON: " + questionsJson);
                    Question[] questions = gson.fromJson(questionsJson, Question[].class);
                    System.out.println("DEBUG: Parsed " + questions.length + " questions");
                    
                    boolean allQuestionsAdded = true;
                    for (int i = 0; i < questions.length; i++) {
                        questions[i].setSurveyId(survey.getId());
                        questions[i].setQuestionOrder(i + 1);
                        
                        System.out.println("DEBUG: Adding question " + (i + 1) + ": " + questions[i].getQuestionText());
                        
                        if (!surveyDAO.addQuestion(questions[i])) {
                            System.err.println("ERROR: Failed to add question " + (i + 1));
                            allQuestionsAdded = false;
                            break;
                        }
                    }
                    
                    if (allQuestionsAdded) {
                        System.out.println("DEBUG: All questions added successfully");
                        out.print("{\"success\": true, \"surveyId\": \"" + survey.getId() + "\"}");
                    } else {
                        System.err.println("ERROR: Failed to add all questions");
                        out.print("{\"success\": false, \"message\": \"Failed to add all questions\"}");
                    }
                } catch (Exception e) {
                    System.err.println("ERROR: Exception processing questions: " + e.getMessage());
                    e.printStackTrace();
                    out.print("{\"success\": false, \"message\": \"Invalid questions format: " + e.getMessage() + "\"}");
                }
            } else {
                System.out.println("DEBUG: No questions provided, survey created without questions");
                out.print("{\"success\": true, \"surveyId\": \"" + survey.getId() + "\"}");
            }
        } else {
            System.err.println("ERROR: Failed to create survey in database");
            out.print("{\"success\": false, \"message\": \"Failed to create survey in database\"}");
        }
        
        out.flush();
        out.close();
    }
    
    private void assignSurvey(HttpServletRequest request, HttpServletResponse response, String adminId) 
            throws IOException {
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            String surveyId = request.getParameter("surveyId");
            String customerId = request.getParameter("customerId");
            String quarter = request.getParameter("quarter");
            String dueDate = request.getParameter("dueDate");
            
            System.out.println("DEBUG: Assign survey parameters - SurveyID: " + surveyId + ", CustomerID: " + customerId + ", Quarter: " + quarter + ", DueDate: " + dueDate);
            
            if (surveyId == null || surveyId.trim().isEmpty() || 
                customerId == null || customerId.trim().isEmpty() || 
                quarter == null || quarter.trim().isEmpty() || 
                dueDate == null || dueDate.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"success\": false, \"message\": \"Missing required parameters\"}");
                out.flush();
                out.close();
                return;
            }
            
            SurveyAssignment assignment = new SurveyAssignment(surveyId, customerId, adminId, quarter, dueDate);
            
            if (surveyDAO.assignSurvey(assignment)) {
                System.out.println("DEBUG: Survey assigned successfully");
                out.print("{\"success\": true}");
            } else {
                System.err.println("ERROR: Failed to assign survey");
                out.print("{\"success\": false, \"message\": \"Failed to assign survey\"}");
            }
        } catch (Exception e) {
            System.err.println("ERROR: Exception in assignSurvey: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"success\": false, \"message\": \"Error: " + e.getMessage() + "\"}");
            e.printStackTrace();
        }
        
        out.flush();
        out.close();
    }
}
