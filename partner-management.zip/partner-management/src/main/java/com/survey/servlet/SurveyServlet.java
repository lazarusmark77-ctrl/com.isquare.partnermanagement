package com.survey.servlet;

import com.survey.dao.SurveyDAO;
import com.survey.dao.ResponseDAO;
import com.survey.model.*;
import com.google.gson.Gson;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class SurveyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private SurveyDAO surveyDAO = new SurveyDAO();
    private ResponseDAO responseDAO = new ResponseDAO();
    private Gson gson = new Gson();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        if (!isAuthenticated(request, response)) {
            return;
        }
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            pathInfo = "/";
        }
        
        System.out.println("DEBUG: SurveyServlet GET request - Path: " + pathInfo + ", User ID: " + user.getId());
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            switch (pathInfo) {
                case "/my-assignments":
                    if ("CUSTOMER".equals(user.getRole())) {
                        List<SurveyAssignment> assignments = surveyDAO.getAssignmentsByCustomer(user.getId());
                        out.print(gson.toJson(assignments));
                    } else {
                        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                        out.print("{\"error\": \"Access denied. Customer role required.\"}");
                    }
                    break;
                    
                case "/details":
                    String assignmentId = request.getParameter("assignmentId");
                    if (assignmentId != null && !assignmentId.trim().isEmpty()) {
                        Survey survey = getSurveyByAssignment(assignmentId, user.getId());
                        if (survey != null) {
                            out.print(gson.toJson(survey));
                        } else {
                            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                            out.print("{\"error\": \"Survey not found or not accessible\"}");
                        }
                    } else {
                        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                        out.print("{\"error\": \"assignmentId parameter is required\"}");
                    }
                    break;
                    
                case "/responses":
                    String responseAssignmentId = request.getParameter("assignmentId");
                    if (responseAssignmentId != null && !responseAssignmentId.trim().isEmpty()) {
                        List<Response> responses = responseDAO.getResponsesByAssignment(responseAssignmentId);
                        out.print(gson.toJson(responses));
                    } else {
                        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                        out.print("{\"error\": \"assignmentId parameter is required\"}");
                    }
                    break;
                    
                default:
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    out.print("{\"error\": \"Endpoint not found\"}");
            }
        } catch (Exception e) {
            System.err.println("ERROR: Exception in SurveyServlet GET: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"" + e.getMessage() + "\"}");
            e.printStackTrace();
        } finally {
            out.flush();
            out.close();
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        if (!isAuthenticated(request, response)) {
            return;
        }
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            pathInfo = "/";
        }
        
        System.out.println("DEBUG: SurveyServlet POST request - Path: " + pathInfo + ", User ID: " + user.getId());
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            switch (pathInfo) {
                case "/submit":
                    submitSurveyResponses(request, response, user.getId());
                    return;
                    
                case "/start":
                    String assignmentId = request.getParameter("assignmentId");
                    if (assignmentId != null && !assignmentId.trim().isEmpty()) {
                        boolean started = surveyDAO.updateAssignmentStatus(assignmentId, "IN_PROGRESS");
                        out.print("{\"success\": " + started + "}");
                    } else {
                        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                        out.print("{\"error\": \"assignmentId parameter is required\"}");
                    }
                    break;
                    
                default:
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    out.print("{\"error\": \"Endpoint not found\"}");
            }
        } catch (Exception e) {
            System.err.println("ERROR: Exception in SurveyServlet POST: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"" + e.getMessage() + "\"}");
            e.printStackTrace();
        } finally {
            out.flush();
            out.close();
        }
    }
    
    private boolean isAuthenticated(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        HttpSession session = request.getSession(false);
        User user = null;
        
        if (session != null) {
            user = (User) session.getAttribute("user");
        }
        
        if (user == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            PrintWriter out = response.getWriter();
            out.print("{\"error\": \"Authentication required\", \"redirect\": \"login.html\"}");
            out.flush();
            out.close();
            return false;
        }
        
        return true;
    }
    
    private Survey getSurveyByAssignment(String assignmentId, String userId) {
        SurveyAssignment assignment = surveyDAO.getAssignmentById(assignmentId, userId);
        if (assignment != null) {
            return surveyDAO.getSurveyWithQuestions(assignment.getSurveyId());
        }
        return null;
    }
    
    private void submitSurveyResponses(HttpServletRequest request, HttpServletResponse response, String userId) 
            throws IOException {
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            String assignmentId = request.getParameter("assignmentId");
            String responsesJson = request.getParameter("responses");
            
            System.out.println("DEBUG: Submit survey responses - AssignmentID: " + assignmentId);
            System.out.println("DEBUG: Responses JSON: " + responsesJson);
            
            if (assignmentId == null || assignmentId.trim().isEmpty() || 
                responsesJson == null || responsesJson.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"success\": false, \"message\": \"Missing required parameters\"}");
                out.flush();
                out.close();
                return;
            }
            
            Response[] responses = gson.fromJson(responsesJson, Response[].class);
            System.out.println("DEBUG: Parsed " + responses.length + " responses");
            
            boolean allSaved = true;
            for (Response resp : responses) {
                resp.setAssignmentId(assignmentId);
                System.out.println("DEBUG: Saving response for question ID: " + resp.getQuestionId());
                
                if (!responseDAO.saveResponse(resp)) {
                    System.err.println("ERROR: Failed to save response for question ID: " + resp.getQuestionId());
                    allSaved = false;
                    break;
                }
            }
            
            if (allSaved) {
                surveyDAO.updateAssignmentStatus(assignmentId, "COMPLETED");
                System.out.println("DEBUG: All responses saved successfully");
                out.print("{\"success\": true}");
            } else {
                System.err.println("ERROR: Failed to save all responses");
                out.print("{\"success\": false, \"message\": \"Failed to save all responses\"}");
            }
        } catch (Exception e) {
            System.err.println("ERROR: Exception in submitSurveyResponses: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"success\": false, \"message\": \"Error: " + e.getMessage() + "\"}");
            e.printStackTrace();
        }
        
        out.flush();
        out.close();
    }
}