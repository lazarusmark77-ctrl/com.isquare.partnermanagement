package com.survey.dao;

import com.survey.model.User;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class UserDAO {
    
    public User authenticate(String username, String password) {
        String sql = "SELECT * FROM " + DatabaseConnection.getSchema() + ".USERS WHERE USERNAME = ? AND PASSWORD_HASH = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, username);
            stmt.setString(2, hashPassword(password));
            
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                User user = new User();
                user.setId(rs.getString("ID"));
                user.setUsername(rs.getString("USERNAME"));
                user.setEmail(rs.getString("EMAIL"));
                user.setRole(rs.getString("ROLE"));
                user.setCreatedAt(rs.getString("CREATED_AT"));
                return user;
            }
            
        } catch (SQLException e) {
            System.err.println("ERROR: Authentication failed: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    public List<User> getCustomers() {
        List<User> customers = new ArrayList<>();
        String sql = "SELECT * FROM " + DatabaseConnection.getSchema() + ".USERS WHERE ROLE = 'CUSTOMER' ORDER BY USERNAME";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                User user = new User();
                user.setId(rs.getString("ID"));
                user.setUsername(rs.getString("USERNAME"));
                user.setEmail(rs.getString("EMAIL"));
                user.setRole(rs.getString("ROLE"));
                customers.add(user);
            }
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to get customers: " + e.getMessage());
            e.printStackTrace();
        }
        
        return customers;
    }
    
    public boolean createUser(User user) {
        String sql = "INSERT INTO " + DatabaseConnection.getSchema() + ".USERS (ID, USERNAME, PASSWORD_HASH, EMAIL, ROLE) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            // Generate new GUID for the user
            String userId = UUID.randomUUID().toString();
            user.setId(userId);
            
            stmt.setString(1, userId);
            stmt.setString(2, user.getUsername());
            stmt.setString(3, hashPassword(user.getPasswordHash()));
            stmt.setString(4, user.getEmail());
            stmt.setString(5, user.getRole());
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to create user: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public User getUserById(String userId) {
        String sql = "SELECT * FROM " + DatabaseConnection.getSchema() + ".USERS WHERE ID = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                User user = new User();
                user.setId(rs.getString("ID"));
                user.setUsername(rs.getString("USERNAME"));
                user.setEmail(rs.getString("EMAIL"));
                user.setRole(rs.getString("ROLE"));
                user.setCreatedAt(rs.getString("CREATED_AT"));
                return user;
            }
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to get user by ID: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    private String hashPassword(String password) {
        // Simple hash for demo - in production, use BCrypt or similar
        return String.valueOf(password.hashCode());
    }
}