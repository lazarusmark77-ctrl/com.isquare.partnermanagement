package com.survey.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {
    // SAP HANA connection parameters
    private static final String HANA_HOST = "c5feaa0f-8c6d-4def-a527-e0e616b9e5d6.hana.prod-eu12.hanacloud.ondemand.com"; // Change to your HANA server host
    private static final String HANA_PORT = "443"; // Default HANA SQL port (change if different)
    private static final String HANA_DATABASE = "HXE"; // Your HANA database name
    private static final String HANA_SCHEMA = "SURVEY_SCHEMA"; // Schema name
    
    // Connection details
    private static final String USERNAME = "DBADMIN"; // Change to your HANA username
    private static final String PASSWORD = "Opal1234"; // Change to your HANA password
    
    // HANA JDBC URL format
    private static final String URL = "jdbc:sap://c5feaa0f-8c6d-4def-a527-e0e616b9e5d6.hana.prod-eu12.hanacloud.ondemand.com:443?encrypt=true&validateCertificate=false&currentschema=SURVEY_SCHEMA";
    
    static {
        try {
            // Load SAP HANA JDBC driver
            Class.forName("com.sap.db.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException("SAP HANA JDBC Driver not found in classpath", e);
        }
    }
    
    public static Connection getConnection() throws SQLException {
        Properties props = new Properties();
        props.put("user", USERNAME);
        props.put("password", PASSWORD);
        
        // Additional HANA-specific connection properties
        props.put("encrypt", "true"); // Set to true for encrypted connections
        props.put("validateCertificate", "false"); // Set to true for certificate validation
        props.put("currentschema", HANA_SCHEMA); // Set default schema
        
        return DriverManager.getConnection(URL, props);
    }
    
    public static Connection getConnectionWithSchema(String schema) throws SQLException {
        Properties props = new Properties();
        props.put("user", USERNAME);
        props.put("password", PASSWORD);
        props.put("currentschema", schema);
        props.put("encrypt", "true");
        props.put("validateCertificate", "false");
        
        String urlWithSchema = "jdbc:sap://c5feaa0f-8c6d-4def-a527-e0e616b9e5d6.hana.prod-eu12.hanacloud.ondemand.com:443?encrypt=true&validateCertificate=false&currentschema=SURVEY_SCHEMA";
        return DriverManager.getConnection(urlWithSchema, props);
    }
    
    // Test connection method
    public static boolean testConnection() {
        try (Connection conn = getConnection()) {
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            System.err.println("Failed to connect to SAP HANA: " + e.getMessage());
            return false;
        }
    }
    
    // Get schema name for use in queries
    public static String getSchema() {
        return HANA_SCHEMA;
    }
}