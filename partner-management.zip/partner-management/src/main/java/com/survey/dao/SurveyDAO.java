package com.survey.dao;

import com.survey.model.Survey;
import com.survey.model.Question;
import com.survey.model.SurveyAssignment;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class SurveyDAO {
    
    public boolean createSurvey(Survey survey) {
        String sql = "INSERT INTO " + DatabaseConnection.getSchema() + ".SURVEYS (ID, TITLE, DESCRIPTION, CREATED_BY) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            // Generate new GUID for the survey
            String surveyId = UUID.randomUUID().toString();
            survey.setId(surveyId);
            
            System.out.println("DEBUG: Creating survey with ID: " + surveyId);
            System.out.println("DEBUG: Survey title: " + survey.getTitle());
            System.out.println("DEBUG: Created by: " + survey.getCreatedBy());
            
            stmt.setString(1, surveyId);
            stmt.setString(2, survey.getTitle());
            stmt.setString(3, survey.getDescription());
            stmt.setString(4, survey.getCreatedBy());
            
            int result = stmt.executeUpdate();
            System.out.println("DEBUG: Insert result: " + result);
            
            if (result > 0) {
                System.out.println("DEBUG: Survey created successfully with ID: " + surveyId);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to create survey: " + e.getMessage());
            System.err.println("ERROR: SQL State: " + e.getSQLState());
            System.err.println("ERROR: Error Code: " + e.getErrorCode());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean addQuestion(Question question) {
        String sql = "INSERT INTO " + DatabaseConnection.getSchema() + ".QUESTIONS (ID, SURVEY_ID, QUESTION_TEXT, QUESTION_TYPE, OPTIONS, IS_REQUIRED, QUESTION_ORDER) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            // Generate new GUID for the question
            String questionId = UUID.randomUUID().toString();
            question.setId(questionId);
            
            System.out.println("DEBUG: Adding question with ID: " + questionId);
            System.out.println("DEBUG: Question text: " + question.getQuestionText());
            
            stmt.setString(1, questionId);
            stmt.setString(2, question.getSurveyId());
            stmt.setString(3, question.getQuestionText());
            stmt.setString(4, question.getQuestionType());
            stmt.setString(5, question.getOptions());
            stmt.setInt(6, question.isRequired() ? 1 : 0);
            stmt.setInt(7, question.getQuestionOrder());
            
            int result = stmt.executeUpdate();
            System.out.println("DEBUG: Question insert result: " + result);
            
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to add question: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public List<Survey> getAllSurveys() {
        List<Survey> surveys = new ArrayList<>();
        String sql = "SELECT * FROM " + DatabaseConnection.getSchema() + ".SURVEYS WHERE IS_ACTIVE = 1 ORDER BY CREATED_AT DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Survey survey = new Survey();
                survey.setId(rs.getString("ID"));
                survey.setTitle(rs.getString("TITLE"));
                survey.setDescription(rs.getString("DESCRIPTION"));
                survey.setCreatedBy(rs.getString("CREATED_BY"));
                survey.setActive(rs.getInt("IS_ACTIVE") == 1);
                survey.setCreatedAt(rs.getString("CREATED_AT"));
                surveys.add(survey);
            }
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to get surveys: " + e.getMessage());
            e.printStackTrace();
        }
        
        return surveys;
    }
    
    public Survey getSurveyWithQuestions(String surveyId) {
        Survey survey = null;
        String surveySQL = "SELECT * FROM " + DatabaseConnection.getSchema() + ".SURVEYS WHERE ID = ?";
        String questionsSQL = "SELECT * FROM " + DatabaseConnection.getSchema() + ".QUESTIONS WHERE SURVEY_ID = ? ORDER BY QUESTION_ORDER";
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            
            // Get survey
            try (PreparedStatement stmt = conn.prepareStatement(surveySQL)) {
                stmt.setString(1, surveyId);
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    survey = new Survey();
                    survey.setId(rs.getString("ID"));
                    survey.setTitle(rs.getString("TITLE"));
                    survey.setDescription(rs.getString("DESCRIPTION"));
                    survey.setCreatedBy(rs.getString("CREATED_BY"));
                    survey.setActive(rs.getInt("IS_ACTIVE") == 1);
                    survey.setCreatedAt(rs.getString("CREATED_AT"));
                }
            }
            
            // Get questions
            if (survey != null) {
                try (PreparedStatement stmt = conn.prepareStatement(questionsSQL)) {
                    stmt.setString(1, surveyId);
                    ResultSet rs = stmt.executeQuery();
                    
                    List<Question> questions = new ArrayList<>();
                    while (rs.next()) {
                        Question question = new Question();
                        question.setId(rs.getString("ID"));
                        question.setSurveyId(rs.getString("SURVEY_ID"));
                        question.setQuestionText(rs.getString("QUESTION_TEXT"));
                        question.setQuestionType(rs.getString("QUESTION_TYPE"));
                        question.setOptions(rs.getString("OPTIONS"));
                        question.setRequired(rs.getInt("IS_REQUIRED") == 1);
                        question.setQuestionOrder(rs.getInt("QUESTION_ORDER"));
                        questions.add(question);
                    }
                    survey.setQuestions(questions);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to get survey with questions: " + e.getMessage());
            e.printStackTrace();
        }
        
        return survey;
    }
    
    public boolean assignSurvey(SurveyAssignment assignment) {
        // Using UPSERT for HANA to handle duplicates
        String sql = "UPSERT " + DatabaseConnection.getSchema() + ".SURVEY_ASSIGNMENTS " +
                    "(ID, SURVEY_ID, CUSTOMER_ID, ASSIGNED_BY, QUARTER, DUE_DATE, STATUS) " +
                    "VALUES (?, ?, ?, ?, ?, ?, 'ASSIGNED') " +
                    "WHERE SURVEY_ID = ? AND CUSTOMER_ID = ? AND QUARTER = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            // Generate new GUID for the assignment
            String assignmentId = UUID.randomUUID().toString();
            assignment.setId(assignmentId);
            
            System.out.println("DEBUG: Creating assignment with ID: " + assignmentId);
            
            stmt.setString(1, assignmentId);
            stmt.setString(2, assignment.getSurveyId());
            stmt.setString(3, assignment.getCustomerId());
            stmt.setString(4, assignment.getAssignedBy());
            stmt.setString(5, assignment.getQuarter());
            stmt.setString(6, assignment.getDueDate());
            stmt.setString(7, assignment.getSurveyId());
            stmt.setString(8, assignment.getCustomerId());
            stmt.setString(9, assignment.getQuarter());
            
            int result = stmt.executeUpdate();
            System.out.println("DEBUG: Assignment insert result: " + result);
            
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to assign survey: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public List<SurveyAssignment> getAssignmentsByCustomer(String customerId) {
        List<SurveyAssignment> assignments = new ArrayList<>();
        String sql = "SELECT sa.*, s.TITLE as SURVEY_TITLE FROM " + DatabaseConnection.getSchema() + ".SURVEY_ASSIGNMENTS sa " +
                    "JOIN " + DatabaseConnection.getSchema() + ".SURVEYS s ON sa.SURVEY_ID = s.ID " +
                    "WHERE sa.CUSTOMER_ID = ? ORDER BY sa.ASSIGNED_AT DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, customerId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                SurveyAssignment assignment = new SurveyAssignment();
                assignment.setId(rs.getString("ID"));
                assignment.setSurveyId(rs.getString("SURVEY_ID"));
                assignment.setCustomerId(rs.getString("CUSTOMER_ID"));
                assignment.setAssignedBy(rs.getString("ASSIGNED_BY"));
                assignment.setAssignedAt(rs.getString("ASSIGNED_AT"));
                assignment.setStatus(rs.getString("STATUS"));
                assignment.setQuarter(rs.getString("QUARTER"));
                assignment.setDueDate(rs.getString("DUE_DATE"));
                assignment.setSurveyTitle(rs.getString("SURVEY_TITLE"));
                assignments.add(assignment);
            }
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to get assignments by customer: " + e.getMessage());
            e.printStackTrace();
        }
        
        return assignments;
    }
    
    public List<SurveyAssignment> getAllAssignments() {
        List<SurveyAssignment> assignments = new ArrayList<>();
        String sql = "SELECT sa.*, s.TITLE as SURVEY_TITLE, u.USERNAME as CUSTOMER_USERNAME " +
                    "FROM " + DatabaseConnection.getSchema() + ".SURVEY_ASSIGNMENTS sa " +
                    "JOIN " + DatabaseConnection.getSchema() + ".SURVEYS s ON sa.SURVEY_ID = s.ID " +
                    "JOIN " + DatabaseConnection.getSchema() + ".USERS u ON sa.CUSTOMER_ID = u.ID " +
                    "ORDER BY sa.ASSIGNED_AT DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                SurveyAssignment assignment = new SurveyAssignment();
                assignment.setId(rs.getString("ID"));
                assignment.setSurveyId(rs.getString("SURVEY_ID"));
                assignment.setCustomerId(rs.getString("CUSTOMER_ID"));
                assignment.setAssignedBy(rs.getString("ASSIGNED_BY"));
                assignment.setAssignedAt(rs.getString("ASSIGNED_AT"));
                assignment.setStatus(rs.getString("STATUS"));
                assignment.setQuarter(rs.getString("QUARTER"));
                assignment.setDueDate(rs.getString("DUE_DATE"));
                assignment.setSurveyTitle(rs.getString("SURVEY_TITLE"));
                assignment.setCustomerUsername(rs.getString("CUSTOMER_USERNAME"));
                assignments.add(assignment);
            }
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to get all assignments: " + e.getMessage());
            e.printStackTrace();
        }
        
        return assignments;
    }
    
    public boolean updateAssignmentStatus(String assignmentId, String status) {
        String sql = "UPDATE " + DatabaseConnection.getSchema() + ".SURVEY_ASSIGNMENTS SET STATUS = ? WHERE ID = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status);
            stmt.setString(2, assignmentId);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to update assignment status: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean reassignSurvey(String assignmentId, String newCustomerId) {
        String sql = "UPDATE " + DatabaseConnection.getSchema() + ".SURVEY_ASSIGNMENTS SET CUSTOMER_ID = ?, STATUS = 'ASSIGNED' WHERE ID = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, newCustomerId);
            stmt.setString(2, assignmentId);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to reassign survey: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public SurveyAssignment getAssignmentById(String assignmentId, String customerId) {
        String sql = "SELECT sa.*, s.TITLE as SURVEY_TITLE FROM " + DatabaseConnection.getSchema() + ".SURVEY_ASSIGNMENTS sa " +
                    "JOIN " + DatabaseConnection.getSchema() + ".SURVEYS s ON sa.SURVEY_ID = s.ID " +
                    "WHERE sa.ID = ? AND sa.CUSTOMER_ID = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, assignmentId);
            stmt.setString(2, customerId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                SurveyAssignment assignment = new SurveyAssignment();
                assignment.setId(rs.getString("ID"));
                assignment.setSurveyId(rs.getString("SURVEY_ID"));
                assignment.setCustomerId(rs.getString("CUSTOMER_ID"));
                assignment.setAssignedBy(rs.getString("ASSIGNED_BY"));
                assignment.setAssignedAt(rs.getString("ASSIGNED_AT"));
                assignment.setStatus(rs.getString("STATUS"));
                assignment.setQuarter(rs.getString("QUARTER"));
                assignment.setDueDate(rs.getString("DUE_DATE"));
                assignment.setSurveyTitle(rs.getString("SURVEY_TITLE"));
                return assignment;
            }
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to get assignment by ID: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    // Test method to verify database connectivity and table existence
    public boolean testDatabaseConnection() {
        String testSql = "SELECT COUNT(*) FROM " + DatabaseConnection.getSchema() + ".SURVEYS";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(testSql)) {
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int count = rs.getInt(1);
                System.out.println("DEBUG: Current survey count: " + count);
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("ERROR: Database connection test failed: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
}