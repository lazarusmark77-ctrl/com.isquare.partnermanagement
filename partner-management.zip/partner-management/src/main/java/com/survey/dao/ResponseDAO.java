package com.survey.dao;

import com.survey.model.Response;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ResponseDAO {
    
    public boolean saveResponse(Response response) {
        // Using UPSERT for HANA to handle duplicate responses
        String sql = "UPSERT " + DatabaseConnection.getSchema() + ".RESPONSES " +
                    "(ID, ASSIGNMENT_ID, QUESTION_ID, RESPONSE_TEXT) " +
                    "VALUES (?, ?, ?, ?) " +
                    "WHERE ASSIGNMENT_ID = ? AND QUESTION_ID = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            // Generate new GUID for the response
            String responseId = UUID.randomUUID().toString();
            response.setId(responseId);
            
            System.out.println("DEBUG: Saving response with ID: " + responseId);
            
            stmt.setString(1, responseId);
            stmt.setString(2, response.getAssignmentId());
            stmt.setString(3, response.getQuestionId());
            stmt.setString(4, response.getResponseText());
            stmt.setString(5, response.getAssignmentId());
            stmt.setString(6, response.getQuestionId());
            
            int result = stmt.executeUpdate();
            System.out.println("DEBUG: Response save result: " + result);
            
            return result > 0;
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to save response: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public List<Response> getResponsesByAssignment(String assignmentId) {
        List<Response> responses = new ArrayList<>();
        String sql = "SELECT r.*, q.QUESTION_TEXT FROM " + DatabaseConnection.getSchema() + ".RESPONSES r " +
                    "JOIN " + DatabaseConnection.getSchema() + ".QUESTIONS q ON r.QUESTION_ID = q.ID " +
                    "WHERE r.ASSIGNMENT_ID = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, assignmentId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Response response = new Response();
                response.setId(rs.getString("ID"));
                response.setAssignmentId(rs.getString("ASSIGNMENT_ID"));
                response.setQuestionId(rs.getString("QUESTION_ID"));
                response.setResponseText(rs.getString("RESPONSE_TEXT"));
                response.setSubmittedAt(rs.getString("SUBMITTED_AT"));
                response.setApproved(rs.getInt("IS_APPROVED") == 1);
                response.setApprovedBy(rs.getString("APPROVED_BY"));
                response.setApprovedAt(rs.getString("APPROVED_AT"));
                response.setQuestionText(rs.getString("QUESTION_TEXT"));
                responses.add(response);
            }
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to get responses by assignment: " + e.getMessage());
            e.printStackTrace();
        }
        
        return responses;
    }
    
    public List<Response> getPendingResponses() {
        List<Response> responses = new ArrayList<>();
        String sql = "SELECT r.*, q.QUESTION_TEXT, s.TITLE as SURVEY_TITLE, u.USERNAME as CUSTOMER_USERNAME " +
                    "FROM " + DatabaseConnection.getSchema() + ".RESPONSES r " +
                    "JOIN " + DatabaseConnection.getSchema() + ".QUESTIONS q ON r.QUESTION_ID = q.ID " +
                    "JOIN " + DatabaseConnection.getSchema() + ".SURVEY_ASSIGNMENTS sa ON r.ASSIGNMENT_ID = sa.ID " +
                    "JOIN " + DatabaseConnection.getSchema() + ".SURVEYS s ON sa.SURVEY_ID = s.ID " +
                    "JOIN " + DatabaseConnection.getSchema() + ".USERS u ON sa.CUSTOMER_ID = u.ID " +
                    "WHERE r.IS_APPROVED = 0";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Response response = new Response();
                response.setId(rs.getString("ID"));
                response.setAssignmentId(rs.getString("ASSIGNMENT_ID"));
                response.setQuestionId(rs.getString("QUESTION_ID"));
                response.setResponseText(rs.getString("RESPONSE_TEXT"));
                response.setSubmittedAt(rs.getString("SUBMITTED_AT"));
                response.setApproved(rs.getInt("IS_APPROVED") == 1);
                response.setQuestionText(rs.getString("QUESTION_TEXT"));
                responses.add(response);
            }
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to get pending responses: " + e.getMessage());
            e.printStackTrace();
        }
        
        return responses;
    }
    
    public boolean approveResponse(String responseId, String approvedBy) {
        String sql = "UPDATE " + DatabaseConnection.getSchema() + ".RESPONSES SET IS_APPROVED = 1, APPROVED_BY = ?, APPROVED_AT = CURRENT_TIMESTAMP WHERE ID = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, approvedBy);
            stmt.setString(2, responseId);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to approve response: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean rejectResponse(String responseId) {
        String sql = "DELETE FROM " + DatabaseConnection.getSchema() + ".RESPONSES WHERE ID = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, responseId);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("ERROR: Failed to reject response: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
}